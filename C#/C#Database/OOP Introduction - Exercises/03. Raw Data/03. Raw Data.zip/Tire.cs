﻿public class Tire
{

}

