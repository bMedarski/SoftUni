﻿public class Car
{
	private string model;

}

