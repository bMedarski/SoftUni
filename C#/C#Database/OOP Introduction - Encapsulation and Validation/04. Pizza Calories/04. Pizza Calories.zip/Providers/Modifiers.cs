﻿static class Modifiers
{
	public const double WHITE = 1.5;
	public const double WHOLEGRAIN = 1.0;
	public const double CRISPY = 0.9;
	public const double CHEWY = 1.1;
	public const double HOMEMADE = 1.0;

	public const double MEAT = 1.2;
	public const double VEGGIES = 0.8;
	public const double CHEESE = 1.1;
	public const double SAUCE = 0.9;
}
