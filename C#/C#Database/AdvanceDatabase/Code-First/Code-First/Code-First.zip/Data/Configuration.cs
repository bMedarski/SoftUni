﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase
{
    public static class Configuration
    {
	    public const string ConnectionString = "Server=.;Database=Hospital;Integrated Security=True";
    }
}
