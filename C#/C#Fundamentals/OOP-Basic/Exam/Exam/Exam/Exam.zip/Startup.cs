﻿using System;

class Startup
{
	static void Main()
	{
		var engine = new Engine();
		engine.Start();
	}
}

