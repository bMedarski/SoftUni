﻿using System.Collections.Generic;

namespace _01.Paw_Inc.Centers
{
    static class AvailableCentres
    {
        public static List<AdoptionCenter> adoptionCenters = new List<AdoptionCenter>();
        public static List<CleansingCenter> cleansingCenters = new List<CleansingCenter>();

    }
}
