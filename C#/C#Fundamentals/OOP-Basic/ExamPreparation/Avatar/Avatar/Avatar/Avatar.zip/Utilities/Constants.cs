﻿public static class Constants
{

	public const string END_OF_PROGRAM = "Quit";

}

