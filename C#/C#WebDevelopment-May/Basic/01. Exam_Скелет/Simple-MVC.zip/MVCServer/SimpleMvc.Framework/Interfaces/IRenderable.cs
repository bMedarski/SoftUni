﻿namespace SimpleMvc.Framework.Interfaces
{
    public interface IRenderable
    {
        string Render();
    }
}
