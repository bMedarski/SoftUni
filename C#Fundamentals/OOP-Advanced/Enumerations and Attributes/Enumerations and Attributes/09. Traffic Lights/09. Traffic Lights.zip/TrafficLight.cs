﻿public enum TrafficLight
{
	Green = 0,
	Yellow = 1,
	Red = 2

}

