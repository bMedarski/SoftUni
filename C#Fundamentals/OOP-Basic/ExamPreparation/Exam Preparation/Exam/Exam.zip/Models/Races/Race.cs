﻿using System.Collections.Generic;
using Exam.Contracts;

namespace Exam.Models
{
    public class Race
    {
        private int length;
        private string route;
        private int prizePool;
        private List<ICar> participants;

        public Race(int length, string route, int prizePool)
        {
            this.Length = length;
            this.Route = route;
            this.PrizePool = prizePool;
            this.participants = new List<ICar>();
        }

        public int Length
        {
            get { return this.length; }
            set { this.length = value; }
        }

        public string Route
        {
            get { return this.route; }
            set { this.route = value; }
        }

        public int PrizePool
        {
            get { return this.prizePool; }
            set { this.prizePool = value; }
        }
        public override string ToString()
        {
            return base.ToString();
        }
    }
}
