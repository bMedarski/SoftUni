﻿using System.Collections.Generic;
using Exam.Contracts;

namespace Exam.Models.Cars
{
    public class PerformanceCar : Car
    {
        private List<string> addOns;

        public PerformanceCar(string brand, string model, int year, int horsepower, int acceleration, int suspension, int durability) 
            : base(brand, model, year, horsepower, acceleration, suspension, durability)
        {
            this.addOns = new List<string>();
            base.Horsepower = (int)(horsepower * 1.5);
            base.Suspension = (int) (suspension * 0.75);
        }
    }
}
