﻿
namespace Exam.Models.Cars
{
    public class ShowCar : Car
    {
        public ShowCar(string brand, string model, int year, int horsepower, int acceleration, int suspension, int durability) 
            : base(brand, model, year, horsepower, acceleration, suspension, durability)
        {
            this.Stars = 0;
        }

        public int Stars { get; set; }
    }
}
