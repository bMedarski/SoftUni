﻿namespace Exam.Contracts
{
    public interface ICar
    {
    }
}
