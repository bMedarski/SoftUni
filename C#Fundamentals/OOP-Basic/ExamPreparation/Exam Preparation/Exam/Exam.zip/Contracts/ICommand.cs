﻿
namespace Exam.Contracts
{
    public interface ICommand
    {
        void Execute();
    }
}
