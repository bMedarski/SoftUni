﻿
namespace Exam.Contracts
{
    public interface IReader
    {
        string ReadLine();
    }
}
