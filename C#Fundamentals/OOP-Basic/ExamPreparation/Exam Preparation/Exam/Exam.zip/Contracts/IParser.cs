﻿namespace Exam.Contracts
{
    public interface IParser
    {
        string ParseCommand(string fullCommand);
    }
}
