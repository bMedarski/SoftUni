﻿using System;
using Exam.Models;
using Exam.Models.Cars;

namespace Exam
{
    class Startup
    {
        static void Main()
        {

            Car racer = new ShowCar("ads","opel",1990,10,5,10,5);
            Console.WriteLine(racer.Suspension);
            Console.WriteLine(racer.Horsepower);
            //Console.WriteLine(racer.Stars);
            var show = new ShowCar("ads", "opel", 1990, 10, 5, 10, 5);
            Console.WriteLine(show.Stars);
            //var engine = Engine.Instance;
            //engine.Start();

        }
    }
}
