﻿namespace Exam.Providers
{
    static class Constants
    {

    }
}
