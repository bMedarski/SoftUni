﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _09.Rectangle_Intersection
{
    public class Rectangle
    {
        private string id;
        private int width;
        private int height;
        private int topLeftX;
        private int topLeftY;

        public Rectangle(string id, int width, int height, int topLX, int topLY)
        {
            this.ID = id;
            this.Width = width;
            this.Height = height;
            this.TopLeftX = topLX;
            this.TopLeftY = topLY;
        }

        public string ID
        {
            get { return this.id; }
            set { this.id = value; }
        }
        public int Width
        {
            get { return this.width; }
            set { this.width = value; }
        }
        public int Height
        {
            get { return this.height; }
            set { this.height = value; }
        }
        public int TopLeftX
        {
            get { return this.topLeftX; }
            set { this.topLeftX = value; }
        }
        public int TopLeftY
        {
            get { return this.topLeftY; }
            set { this.topLeftY = value; }
        }
    }
}
