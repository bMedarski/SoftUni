const BASE_URL = 'https://baas.kinvey.com/';
const APP_KEY = 'kid_SkK8RiPwQ';
const APP_SECRET = '23c696329b694aa8bbddd7461b8cc099';

const APP_DATA = "appdata";
const AUTH_METHOD = "kinvey";

const PASSWORD_LENGTH = 6;
const USERNAME_LENGTH = 3;

const MEME_TITLE = 33;
const MEME_DESCRIPTION_MIN = 30;
const MEME_DESCRIPTION_MAX = 450;