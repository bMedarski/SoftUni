const homeHandler = require('./homeHandler')
const memeHandler = require('./memeHandler')
const staticHandler = require('./staticHandler')

module.exports = [homeHandler, memeHandler, staticHandler]
