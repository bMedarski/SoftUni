
module.exports = (req, res) => {
  if (req.pathname === '/search') {
   
  } else {
    return true
  }
}
