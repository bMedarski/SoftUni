
module.exports = (req, res) => {
  if (req.pathname === '/generateTag' && req.method === 'POST') {

  } else {
    return true
  }
}
